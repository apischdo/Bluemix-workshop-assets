import sys
import os
import requests
import json

"""
Script for uploading files from a local directory to your WDS collection.
20KB files take about 1 second to upload each depending on network speed.
Tested on Mac with Python 2.7 and requests package installed (pip install requests).
Takes in seed directory or file as argument one and path to credentials json file as second argument.

Author: Allegra Larche
"""


def uploadFile(path, credentials):
    if not os.path.isfile(path) or not(path.endswith(".pdf") or path.endswith(".html") or path.endswith(".json") or path.endswith(".doc") or path.endswith(".docx")):
        print "Ignoring " + path + " because it is an unsupported file type."
        return

    # read in credentials
    try:
        username = credentials['username']
        password = credentials['password']
        environment = credentials['environmentid']
        collection = credentials['collectionid']
        apiurl = credentials['apiurl']
        version = credentials['version']
    except:
        sys.exit("Missing one or more fields from credentials file.")

    # construct request
    if apiurl.endswith("/"):
        apiurl = apiurl[0:len(apiurl) - 1]
    discoveryurl = apiurl + "/environments/" + environment + "/collections/"+ collection + "/documents?version=" + version
    files = {
    'file' : (path, open(path, 'rb'))
    }
    response = requests.post(discoveryurl, auth = (username, password), files=files)

    if not(response.status_code is 200 or response.status_code is 202):
        print "error with " + path
        print response.text

def iterateOverFiles(path, credentials):
    if os.path.isdir(path):
        print "In directory " + path
        paths = os.listdir(path)
        count = 0
        for p in paths:
            count = count + iterateOverFiles(path + "/" + p, credentials)
        return count
    elif os.path.isfile(path):
        uploadFile(path, credentials)
        return 1
    else:
        print "Ignoring " + path + " because it is not a file or directory."
        return 0

def main():
    if len(sys.argv) < 3:
        sys.exit("Usage: python discovery_filesystem_upload.py /path/to/seed/dir /path/to/json/credentials")
    seed = sys.argv[1]
    with open(sys.argv[2]) as credentialfile:
        credentials = json.load(credentialfile)
    if seed.endswith("/"):
        seed = seed[0:len(seed) - 1]
    print str(iterateOverFiles(seed, credentials)) + " documents successfully uploaded!"




if __name__ == "__main__":
    main()
