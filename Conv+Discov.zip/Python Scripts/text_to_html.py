import sys
import os

"""
Script for converting files in a local directory from .txt to .html.
Tested on Mac with Python 2.7.

Example Usage: python text_to_html.py ./my_directory true
Takes in seed directory or file as argument one and whether or not you want the old txt files deleted as a second optional argument

Author: Allegra Larche
"""

def addTags(file):
    if not file.endswith(".txt"):
        print file + " not a txt file"
        return
    text = open(file, "rb")
    out = open(file.replace(".txt", ".html"), "w")
    out.write("<html>\n")
    for line in text:
        out.write(line)
    out.write("</html>")
    out.close()
    text.close()

def iterateOverFiles(path, delete):
    if os.path.isdir(path): # if folder, convert all files in the folder
        print "In directory " + path
        paths = os.listdir(path)
        for p in paths:
            iterateOverFiles(path + "/" + p)
    elif os.path.isfile(path): # if it's a file just convert the file
        addTags(path)
        if delete and path.endswith(".txt"):
            os.remove(path)
            print(path + " removed")
    else:
        print "Ignoring " + path + " because it is not a directory or file"

def main():
    if len(sys.argv) < 2:
        sys.exit("Usage: python text_to_html.py /path/to/seed/dir [true|false]")
    fname = sys.argv[1]
    if fname.endswith("/"):
        fname = fname[0:len(fname) - 1]
    delete = False
    if len(sys.argv) > 2 and sys.argv[2] == "true":
        delete = True
    iterateOverFiles(fname, delete)




if __name__ == "__main__":
    main()
