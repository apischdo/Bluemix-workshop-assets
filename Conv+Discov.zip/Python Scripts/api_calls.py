import json
import requests

"""
Prereqs:
python 2.7
requests package installed (pip install requests)

Usage:
python
> from api_calls import Discovery
> d = Discovery("username", "password")
> d.listEnvironments()
> environmentid = "environmentid-returned-from-previous-call"
> d.listCollections(environmentid)
> collectionid = "collectionid-returned-from-previous-call"
> d.addDocument(environmentid, collectionid, "path/to/doc.html")
> docid = "docid-returned-from-previous-call"
> d.listDocumentDetails(environmentid, collectionid, docid)
// make sure that status of doc is saved and indexed
> d.query(environmentid, collectionid, "count=7&filter=enriched.text.entity.text:IBM")
> exit()

* Not a ton of error checking done
Author: Allegra Larche
"""



class Discovery:

    def __init__(self, username, password, url="https://gateway.watsonplatform.net/discovery-experimental/api/v1", version="2016-11-07"):
        self.username = username
        self.password = password
        self.url = url # TODO: if url ends in slash remove
        self.version = version

    ### ENVIRONMENTS ###

    # Create - yet to be tested because can't create more than one environment
    def createEnvironment(self, name, description=""):
        url = self.url + "/environments?version=" + self.version
        headers = {
        "Content-Type": "application/json"
        }
        data = {
        "name": name,
        "description": description
        }
        response = requests.post(url, json = data, headers = headers, auth = (self.username, self.password))
        return response.status_code, response.json()

    # List
    def listEnvironments(self):
        url = self.url + "/environments?version=" + self.version
        response = requests.get(url, auth = (self.username, self.password))
        return response.status_code, response.json()

    # List Details
    def listEnvironmentDetails(self, environmentid):
        url = self.url + "/environments/" + environmentid + "?version=" + self.version
        response = requests.get(url, auth = (self.username, self.password))
        return response.status_code, response.json()

    # Update
    def updateEnvironment(self, environmentid, name, description=""):
        url = self.url + "/environments/" + environmentid + "?version=" + self.version
        headers = {
        "Content-Type": "application/json"
        }
        data = {
        "name": name,
        "description": description
        }
        response = requests.put(url, json = data, headers = headers, auth = (self.username, self.password))
        return response.status_code, response.json()

    # Delete
    def deleteEnvironment(self, environmentid):
        url = self.url + "/environments/" + environmentid + "?version=" + self.version
        response = requests.delete(url, auth = (self.username, self.password))
        return response.status_code, response.json()

    ### CONFIGURATIONS ###

    # Create - path is path to json file containing config
    def createConfig(self, environmentid, path):
        url = self.url + "/environments/" + environmentid + "/configurations?version=" + self.version
        headers = {
        "Content-Type": "application/json"
        }
        files = {
        'configuration' : (path, open(path, 'rb'))
        }
        response = requests.post(url, files=files, headers = headers, auth = (self.username, self.password))
        return response.status_code, response.json()

    # List
    def listConfigs(self, environmentid):
        url = self.url + "/environments/" + environmentid + "/configurations?version=" + self.version
        response = requests.get(url, auth = (self.username, self.password))
        return response.status_code, response.json()

    # List Details
    def listConfigDetails(self, environmentid, configid):
        url = self.url + "/environments/" + environmentid + "/configurations/" + configid + "?version=" + self.version
        response = requests.get(url, auth = (self.username, self.password))
        return response.status_code, response.json()

    # Update
    def updateConfig(self, environmentid, configid, path):
        url = self.url + "/environments/" + environmentid + "/configurations/" + configid + "?version=" + self.version
        headers = {
        "Content-Type": "application/json"
        }
        files = {
        'configuration' : (path, open(path, 'rb'))
        }
        response = requests.put(url, files=files, headers = headers, auth = (self.username, self.password))
        return response.status_code, response.json()

    # Delete
    def deleteConfig(self, environmentid, configid):
        url = self.url + "/environments/" + environmentid + "/configurations/" + configid + "?version=" + self.version
        response = requests.delete(url, auth = (self.username, self.password))
        return response.status_code, response.json()

    ### PREVIEW ###

    #TODO

    ### COLLECTIONS ###

    # Create
    def createCollection(self, environmentid, configid, name, description="", language="en_us"):
        url = self.url + "/environments/" + environmentid + "/collections?version=" + self.version
        headers = {
        "Content-Type": "application/json"
        }
        data = {
        "name": name,
        "description": description,
        "configuration_id": configid,
        "language": language
        }
        response = requests.post(url, json=data, headers = headers, auth = (self.username, self.password))
        return response.status_code, response.json()

    # List
    def listCollections(self, environmentid): #TODO: optional argument "name"?
        url = self.url + "/environments/" + environmentid + "/collections?version=" + self.version
        response = requests.get(url, auth = (self.username, self.password))
        return response.status_code, response.json()

    # List Details
    def listCollectionDetails(self, environmentid, collectionid):
        url = self.url + "/environments/" + environmentid + "/collections/" + collectionid + "?version=" + self.version
        response = requests.get(url, auth = (self.username, self.password))
        return response.status_code, response.json()

    # Update
    def updateCollection(self, environmentid, collectionid, configid, name, description="", language="en_us"):
        url = self.url + "/environments/" + environmentid + "/collections/" + collectionid + "?version=" + self.version
        headers = {
        "Content-Type": "application/json"
        }
        data = {
        "name": name,
        "description": description,
        "configuration_id": configid,
        "language": language
        }
        response = requests.post(url, json=data, headers = headers, auth = (self.username, self.password))
        return response.status_code, response.json()

    # List Fields
    #TODO

    # Delete
    #TODO

    ### DOCUMENTS ###

    # Add
    def addDocument(self, environmentid, collectionid, path, configid=None): #TODO extra fields
        url = self.url + "/environments/" + environmentid + "/collections/"+ collectionid + "/documents?version=" + self.version
        files = {
        'file' : (path, open(path, 'rb'))
        }
        response = requests.post(url, auth = (self.username, self.password), files=files)
        return response.status_code, response.json()

    # Update
    #TODO

    # List Details
    def listDocumentDetails(self, environmentid, collectionid, documentid):
        url = self.url + "/environments/" + environmentid + "/collections/" + collectionid + "/documents/" + documentid + "?version=" + self.version
        response = requests.get(url, auth = (self.username, self.password))
        return response.status_code, response.json()

    # Delete
    def deleteDocument(self, environmentid, collectionid, documentid):
        url = self.url + "/environments/" + environmentid + "/collections/" + collectionid + "/documents/" + documentid + "?version=" + self.version
        response = requests.delete(url, auth = (self.username, self.password))
        return response.status_code, response.json()

    ### QUERY ###
    # query can be object with fields or string with fields separated by &
    def query(self, environmentid, collectionid, query):
        url = self.url + "/environments/" + environmentid + "/collections/" + collectionid + "/query?version=" + self.version
        if isinstance(query, dict):
            if query['filter']:
                url = url + "&filter=" + query['filter']
            if query['query']:
                url = url + "&query=" + query['query']
            if query['aggregation']:
                url = url + "&aggregation=" + query['aggregation']
            if query['count']:
                url = url + "&count=" + query['count']
            if query['return']:
                url = url + "&return=" + query['return']
        elif isinstance(query, str):
            url = url + "&" + query
        response = requests.get(url, auth=(self.username, self.password))
        return response.status_code, response.json()

    def detectType(self, path):
        if path.endswith(".html"):
            return "text/html"
        if path.endswith(".doc"):
            return "application/msword"
        if path.endswith(".docx"):
            return "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        if path.endswith(".pdf"):
            return "application/pdf"
        if path.endswith(".json"):
            return "application/json"
