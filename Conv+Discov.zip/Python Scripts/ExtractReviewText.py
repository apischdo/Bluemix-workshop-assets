import json
import os

inbase = "/Users/allegralarche/WDS/HomeKitchen/"
paths = os.listdir(inbase)
outbase = "/Users/allegralarche/WDS/HomeKitchenText/"
i = 0
for path in paths:
    f = open(inbase + path)
    doc = json.load(f)
    f.close()
    outpath = outbase + path.split(".")[0] + ".txt"
    if i % 50 == 0:
        print outpath
    outfile = open(outpath, 'w')
    outfile.write(doc['reviewText'])
    outfile.close()
    i = i + 1
