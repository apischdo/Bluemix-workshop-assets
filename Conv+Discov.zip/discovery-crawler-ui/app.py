# Copyright 2015 IBM Corp. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import requests
import configCreator
from flask import Flask, json, request, render_template, session, redirect, url_for

app = Flask(__name__)
baseurl = "https://gateway.watsonplatform.net/discovery-experimental/api/v1"
version = "2016-11-07"

@app.route('/', methods=['POST', 'GET'])
def Welcome():
    if request.method == 'GET':
        return render_template('login.html')
    if request.method == 'POST':
        session['username'] = request.form['username']
        session['password'] = request.form['password']
        return redirect(url_for('ListEnvironments'))


@app.route('/environments', methods=['POST', 'GET'])
def ListEnvironments():
    if 'username' in session:
        if request.method == 'GET':
            url = baseurl + "/environments?version=" + version
            response = requests.get(url, auth = (session['username'], session['password']))
            if not response.status_code is 200:
                return json.jsonify(results=response.json())
            returnjson = response.json()
            return render_template('environments.html', environments=returnjson['environments'])
        if request.method == 'POST':
            eid = request.form['environment']
            return redirect(url_for('ListCollections', eid = eid))
    return redirect(url_for('Welcome'))

@app.route('/environments/<eid>/collections', methods=['POST', 'GET'])
def ListCollections(eid):
    if 'username' in session:
        if request.method == 'GET':
            url = baseurl + "/environments/" + eid + "/collections?version=" + version
            response = requests.get(url, auth = (session['username'], session['password']))
            if not response.status_code is 200:
                return json.jsonify(results=response.json())
            returnjson = response.json()
            return render_template('collections.html', collections=returnjson['collections'])
        if request.method == 'POST':
            both = request.form['collection'].split("||")
            cid = both[0]
            configid = both[1]
            return redirect(url_for('ConfigureCrawler', eid = eid, cid = cid, configid = configid))
    return redirect(url_for('Welcome'))

@app.route('/environments/<eid>/collections/<cid>/<configid>', methods=['POST', 'GET'])
def ConfigureCrawler(eid, cid, configid):
    if 'username' in session:
        if request.method == 'GET':
            return render_template('configure.html')
        if request.method == 'POST':
            seed = request.form['seed']
            credentials = {
            'username' : session['username'],
            'password' : session['password'],
            'eid' : eid,
            'cid' : cid,
            'configid' : configid
            }
            try:
                configCreator.updateDiscovery(credentials)
                configCreator.updateSeed(seed)
            except:
                return json.jsonify(results="Error! One or more invalid fields")
            return render_template('instructions.html')
    return redirect(url_for('Welcome'))

app.secret_key = '!(\x9c\xfdh\xff\x9f\x1e\xd4\xbeO\xfdO\x1b\x04\x00R\xe5\t*\xc8>\xb9\xe29j\x0c[n\xce'


port = os.getenv('PORT', '5000')
if __name__ == "__main__":
	app.run(host='0.0.0.0', port=int(port))
