# Crawler Configuration Generator
A web interface for automatically generating the configuration folder needed to run the Discovery Service crawler over a directory on a local filesystem. Meant to be run locally since the crawler must be run on the system where the filesystem resides.

## About the Crawler
The crawler is a java application which is run using a shell script via the command line. It reads from a configuration folder and then uses the information in those files to connect to the user's discovery service instance, crawl from the designated seed directory, and upload the files in the directory via the ingestion endpoint of the Discovery API. It can be used to crawl local filesystems, databases, or share folders.

## Requirements
- Python 2.7
- Flask, Requests installed (pip install flask, pip install requests)
- Discovery Service set up and collection where you'd like to upload the documents to created

## Instructions
To run the web app (from command line):
- Navigate to discovery-crawler-ui folder
- Set app.py as FLASK_APP environment variable
  - MAC/UNIX: export FLASK_APP=app.py
  - Windows: SET FLASK_APP=app.py
- Type: flask run
- Navigate to localhost:5000 on browser

To run the crawler:
- Make sure crawler binary folder is added to your PATH
- Copy the config folder within discovery-crawler-ui into another directory and navigate to that directory
- Run: crawler crawl

## Notes
The Discovery Service currently rate limits its users to 100 documents in the ingestion queue at a time. If you start receiving status codes of 429, this means you have hit the rate limit and should wait to upload more documents. The best way to avoid hitting the limit is to run the crawler in 100 document increments. Updates to the crawler will be able to handle this situation, but the current implementation does not.

## More on the Crawler
Detailed information about the crawler and all of its configuration points can be found in the [Discovery Service Documentation](https://www.ibm.com/watson/developercloud/doc/discovery/adding_content.shtml#defaultconfig).
To manually configure the crawler yourself, follow the instructions [here](https://github.ibm.com/Watson-Implementations-Practice/discovery-prototype/blob/master/Documentation/data_crawler_instructions.md) which give quick and easy steps to get the crawler set up to crawl a local directory.
