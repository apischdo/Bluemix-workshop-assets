import os

seedPath = './config/seeds/filesystem-seed.conf'
discoPath = './config/discovery/discovery_service.conf'

def updateDiscovery(credentials):
    head, tail = os.path.split(discoPath)
    # create temp out file
    tmpName = os.path.join(head, "tmp.conf")
    tmp = open(tmpName, 'w')
    # open input file
    inputFile = open(discoPath, 'r')
    # copy lines from in to out but replace seed line with <seed>
    line = inputFile.readline()
    while line:
        sansWhite = "".join(line.split())
        if sansWhite.startswith("environment_id"):
            tmp.write("\tenvironment_id=\"" + credentials['eid'] + "\",\n")
        elif sansWhite.startswith("collection_id"):
            tmp.write("\tcollection_id=\"" + credentials['cid'] + "\",\n")
        elif sansWhite.startswith("configuration_id"):
            tmp.write("\tconfiguration_id=\"" + credentials['configid'] + "\",\n")
        elif sansWhite.startswith("username="):
            tmp.write("\t\tusername=\"" + credentials['username'] + "\",\n")
        elif sansWhite.startswith("password="):
            tmp.write("\t\tpassword=\"" + credentials['password'] + "\"\n")
        else:
            tmp.write(line)
        line = inputFile.readline()
    tmp.close()
    inputFile.close()

    # delete input file
    os.remove(discoPath)

    # rename
    os.rename(tmpName, discoPath)

def updateSeed(seed):
    head, tail = os.path.split(seedPath)
    # create temp out file
    tmpName = os.path.join(head, "tmp.conf")
    tmp = open(tmpName, 'w')
    # open input file
    inputFile = open(seedPath, 'r')
    # copy lines from in to out but replace seed line with <seed>
    line = inputFile.readline()
    while line:
        if "".join(line.split()).startswith("name=\"url\""):
            tmp.write(line)
            inputFile.readline()
            tmp.write("\t\t\tvalue=\"sdk-fs://" + seed + "\"\n")
        else:
            tmp.write(line)
        line = inputFile.readline()
    tmp.close()
    inputFile.close()

    # delete input file
    os.remove(seedPath)

    # rename
    os.rename(tmpName, seedPath)
