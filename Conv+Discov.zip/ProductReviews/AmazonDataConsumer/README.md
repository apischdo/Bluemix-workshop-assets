# Amazon Data Consumer

## System

Input: File with one JSON document = 1 Amazon review per line

Ouput: Either writes each document to a database or to a folder on the local filesystem

## Classes

* Tester.java: Main class from which workflow, input files, and output files are instantiated.
* WorkFlow.java: As the name suggests, workflow for the entire system where all other classes get instantiated and called from. Need to fill out host, port dbName, username, and password for your JDBC database in the constructor in order to use.
  * processJsonToDatabase(file) takes in a file with one JSON document representing an Amazon review per row and inserts each document as a row into your database.
  * processJsonToFilesystem(file, directory, format) takes in same file but writes each document as new file to directory with specified format
* AmazonReview.java: Object representing AmazonReview document with getters and setters for each relevant field in the document and methods for writing object in different file formats.
* DB2Conn and PostgressConn: Singleton connections to db2 and postgres databases.
* StoreKeeper: Handles any SQL querying for inserting reviews into database.

## To Run

1. Fill in database credentials in WorkFlow
2. Fill in path to input and output files in Tester
3. `mvn clean install`
4. Run Tester
