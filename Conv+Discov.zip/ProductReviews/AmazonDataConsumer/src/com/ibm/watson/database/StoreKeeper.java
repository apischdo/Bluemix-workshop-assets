package com.ibm.watson.database;

import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.util.ArrayList;

//import com.ibm.watson.libtest.objects.*;

import com.ibm.watson.objects.AmazonReview;

public class StoreKeeper {
	 public static final String copyrightStatement =
		        "Licensed Materials - Property of IBM\n\n" +
		        "(c) Copyright IBM Corp. 2014 All Rights Reserved\n\n" +
		        "US Government Users Restricted Rights - Use, duplication or\n" +
		        "disclosure restricted by GSA ADP Schedule Contract with\n" +
		        "IBM Corp";

	private Connection connection = null;
	private String schema = "db2inst1";
	
	public StoreKeeper(Connection connection) {
		super();
		this.connection = connection;
	}
	
	public void close() {
		try {
			connection.close();
		}
		catch (Exception e) {
			System.out.println("Exception closing StoreKeeper: " + e.toString());
		}
	}
	
	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public void insertReviews(ArrayList<AmazonReview> reviews) {
		System.out.println("insertReviews Entered");
		
		PreparedStatement statement = null;

		String query = "INSERT INTO reviews(reviewer_id, product_id, helpful, not_helpful, review_text, rating, summary, review_date, time_inserted) " +
				       "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		try {
			connection.setAutoCommit(false);
	
			statement = connection.prepareStatement(query);
			statement.setTimestamp(9, new Timestamp(new Date().getTime()));		

			for(int i = 0; i < reviews.size(); i++){
				AmazonReview review = reviews.get(i);
				statement.setString(1, review.getReviewerId());	
				statement.setString(2, review.getProductId());	
				statement.setLong(3, review.getHelpful());
				statement.setLong(4, review.getNotHelpful());
				statement.setString(5, review.getReviewText());
				statement.setDouble(6, review.getRating());
				statement.setString(7, review.getSummary());
				statement.setTimestamp(8, new Timestamp(new Date(review.getReviewDate()*1000).getTime()));
				statement.executeUpdate();
			}
			
			connection.commit();
			
			// Clean up after all endorsements inserted into the database
			statement = GenericDBFunctions.closePstmt(statement);
			
		}
		catch(Exception e){
			System.out.println("Error insertReviews: " + e.toString()); 
			e.printStackTrace();
			statement = GenericDBFunctions.closePstmt(statement);
		}
	}

}
