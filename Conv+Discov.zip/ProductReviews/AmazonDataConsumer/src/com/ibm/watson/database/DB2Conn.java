package com.ibm.watson.database;

import java.sql.Connection;
import java.sql.DriverManager;

public class DB2Conn {
	 public static final String copyrightStatement =
		        "Licensed Materials - Property of IBM\n\n" +
		        "(c) Copyright IBM Corp. 2014 All Rights Reserved\n\n" +
		        "US Government Users Restricted Rights - Use, duplication or\n" +
		        "disclosure restricted by GSA ADP Schedule Contract with\n" +
		        "IBM Corp";

	private static DB2Conn instance = null;
	
	private String dbHost; 
	private String dbPort; 
	private String dbName;
	private String dbUser;
	private String dbPassword;
	
	private boolean connectSuccess = false;
	
	public Connection connection;

	public DB2Conn(String dbHost, String dbPort, String dbName, String dbUser, String dbPassword) {
		super();

		this.dbHost = dbHost;
		this.dbPort = dbPort;
		this.dbName = dbName;
		this.dbUser = dbUser;
		this.dbPassword = dbPassword;
		
		establishJDBCConnection();
	}
	
	public static DB2Conn getInstance(String dbHost, String dbPort, String dbName, String dbUser, String dbPassword) {
		if (instance == null) {
			instance = new DB2Conn(dbHost, dbPort, dbName, dbUser, dbPassword);
		}
		return instance;
	}
	
	private void establishJDBCConnection() {
		System.out.println("Entered establishJDBCConnection");
    	try {
            Class.forName("com.ibm.db2.jcc.DB2Driver");
            //Construct the JDBC URL - jdbc:db2://localhost:50000/Tin008
            String url = "jdbc:db2://" + dbHost + ":" + dbPort + "/" + dbName;
            
            connection = DriverManager.getConnection(url, dbUser, dbPassword);
			connectSuccess = true;
         }
         catch (Exception e) {
			connectSuccess = false;
         	e.printStackTrace();
         }
	}

	/**
	 * @return
	 */
	public Connection getConnection() {
		return connection;
	}

	/**
	 * @return
	 */
	public boolean isConnected() {
		return connectSuccess;
	}

}
