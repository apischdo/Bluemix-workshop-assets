package com.ibm.watson.database;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class GenericDBFunctions {
	 public static final String copyrightStatement =
		        "Licensed Materials - Property of IBM\n\n" +
		        "(c) Copyright IBM Corp. 2014 All Rights Reserved\n\n" +
		        "US Government Users Restricted Rights - Use, duplication or\n" +
		        "disclosure restricted by GSA ADP Schedule Contract with\n" +
		        "IBM Corp";

	public static PreparedStatement closePstmt(PreparedStatement pstmt){
		try {
			if(pstmt != null){
				pstmt.close();
				pstmt = null;
			}
		}
		catch(Exception e) {
			return null;
		}		
		return pstmt;
	}

	public static CallableStatement closeCstmt(CallableStatement cstmt){
		try {
			if(cstmt != null){
				cstmt.close();
				cstmt = null;
			}
		}
		catch(Exception e) {
			return null;
		}		
		return cstmt;
	}

	public static Statement closeStmt(Statement stmt){
		try {
			if(stmt != null){
				stmt.close();
				stmt = null;
			}
		}
		catch(Exception e) {
			return null;
		}		
		return stmt;
	}

	
	public static ResultSet closeResults(ResultSet results){
		try {
			if(results != null){
				results.close();
				results = null;
			}
		}
		catch(Exception e) {
			return null;
		}		
		
		return results;
	}

}
