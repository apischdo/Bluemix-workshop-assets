package com.ibm.watson.database;

import java.sql.Connection;
import java.sql.DriverManager;

public class PostgressConn {
	 public static final String copyrightStatement =
		        "Licensed Materials - Property of IBM\n\n" +
		        "(c) Copyright IBM Corp. 2014 All Rights Reserved\n\n" +
		        "US Government Users Restricted Rights - Use, duplication or\n" +
		        "disclosure restricted by GSA ADP Schedule Contract with\n" +
		        "IBM Corp";

	private static PostgressConn instance = null;
	
	private String dbHost; 
	private String dbPort; 
	private String dbName;
	private String dbUser;
	private String dbPassword;
	
	private boolean connectSuccess = false;
	
	public Connection connection;

	public PostgressConn(String dbHost, String dbPort, String dbName, String dbUser, String dbPassword) {
		super();

		this.dbHost = dbHost;
		this.dbPort = dbPort;
		this.dbName = dbName;
		this.dbUser = dbUser;
		this.dbPassword = dbPassword;
		
		establishJDBCConnection();
	}
	
	public static PostgressConn getInstance(String dbHost, String dbPort, String dbName, String dbUser, String dbPassword) {
		if (instance == null) {
			instance = new PostgressConn(dbHost, dbPort, dbName, dbUser, dbPassword);
		}
		return instance;
	}
	
	private void establishJDBCConnection() {
		System.out.println("Entered establishJDBCConnection");
 	try {
         Class.forName("org.postgresql.Driver");
         
         //Construct the JDBC URL - jdbc:postgresql://127.0.0.1:5432/tin7f
         String url = "jdbc:postgresql://" + dbHost + ":" + dbPort + "/" + dbName;
         
         connection = DriverManager.getConnection(url, dbUser, dbPassword);
         connectSuccess = true;
      }
      catch (Exception e) {
    	  connectSuccess = false;
    	  e.printStackTrace();
      }
	}

	
	/**
	 * @return
	 */
	public Connection getConnection() {
		return connection;
	}

	/**
	 * @return
	 */
	public boolean isConnected() {
		return connectSuccess;
	}

}
