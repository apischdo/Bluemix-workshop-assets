package com.ibm.watson.tester;

import com.ibm.watson.core.WorkFlow;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WorkFlow wf = new WorkFlow();
		String inputFile = "/Users/allegralarche/WDS/discovery-prototype/ProductReviews/1000.json";
		String outputDir = "/Users/allegralarche/WDS/HomeKitchen";
		
		wf.processJsonToDataBase(inputFile);
		//wf.processJsonToFileSystem(inputFile, outputDir, "html");
		


		
	}

}
