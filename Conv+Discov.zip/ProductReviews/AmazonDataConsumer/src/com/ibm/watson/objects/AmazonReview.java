package com.ibm.watson.objects;

import org.json.simple.JSONObject;

public class AmazonReview {

	private String reviewerId;
	private String productId;
	private long helpful;
	private long notHelpful;
	private String reviewText;
	private double rating;
	private String summary;
	private long reviewDate;
	
	public AmazonReview() {
		
	}
	
	public String getReviewerId() {
		return reviewerId;
	}
	
	public void setReviewerId(String reviewerId) {
		this.reviewerId = reviewerId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	public long getHelpful() {
		return helpful;
	}

	public void setHelpful(long helpful) {
		this.helpful = helpful;
	}
	
	public long getNotHelpful() {
		return notHelpful;
	}

	public void setNotHelpful(long notHelpful) {
		this.notHelpful = notHelpful;
	}

	public String getReviewText() {
		return reviewText;
	}

	public void setReviewText(String reviewText) {
		this.reviewText = reviewText;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}
	
	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public long getReviewDate() {
		return reviewDate;
	}

	public void setReviewDate(long reviewDate) {
		this.reviewDate = reviewDate;
	}
	
	public String constructPlainText() {
		String returnText = new String();
		
		returnText = "Product Id: " + this.productId + "\n";
		returnText = returnText + "Reviewer Id: " + this.reviewerId + "\n";
		returnText = returnText + "Helpful: " + this.helpful + "\n";
		returnText = returnText + "Not Helpful: " + this.notHelpful + "\n";
		returnText = returnText + "Review Text: " + this.reviewText + "\n";
		returnText = returnText + "Rating: " + this.rating + "\n";
		returnText = returnText + "Summary: " + this.summary + "\n";
		returnText = returnText + "Unix Date: " + this.reviewDate;

		return returnText;
	}

	public String constructHTML() {
		String returnText = new String();
		returnText = "<!DOCTYPE html>\n<html>\n<body>\n";
		returnText = "Product Id: " + this.productId + "\n";
		returnText = returnText + "Reviewer Id: " + this.reviewerId + "\n";
		returnText = returnText + "Helpful: " + this.helpful + "\n";
		returnText = returnText + "Not Helpful: " + this.notHelpful + "\n";
		returnText = returnText + "Review Text: " + this.reviewText + "\n";
		returnText = returnText + "Rating: " + this.rating + "\n";
		returnText = returnText + "Summary: " + this.summary + "\n";
		returnText = returnText + "Unix Date: " + this.reviewDate;
		returnText = returnText + "</body>\n</html>";

		return returnText;
	}

	public String constructXML() {
		String returnText = new String();
		returnText = "<?xml version=\"1.0\"?>\n<Review>\n";
		returnText = returnText + "<ProductId>" + this.productId + "</ProductId>\n";
		returnText = returnText + "<ReviewerId>" + this.reviewerId + "</ReviewerId>\n";
		returnText = returnText + "<Helpful>" + this.helpful + "</Helpful>\n";
		returnText = returnText + "<NotHelpful>" + this.notHelpful + "</NotHelpful>\n";
		returnText = returnText + "<ReviewText>" + this.reviewText + "</ReviewText>\n";
		returnText = returnText + "<Rating>" + this.rating + "</Rating>\n";
		returnText = returnText + "<Summary>" + this.summary + "</Summary>\n";
		returnText = returnText + "<UnixDate>" + this.reviewDate + "</UnixDate>\n";
		returnText = returnText + "</Review>";

		return returnText;
	}
	
	@SuppressWarnings("unchecked")
	public String constructJson() {
		JSONObject obj = new JSONObject();
		obj.put("product_id", this.productId);
		obj.put("reviewer_id", this.reviewerId);
		obj.put("helpful", this.helpful);
		obj.put("not_helpful", this.notHelpful);
		obj.put("review_text", this.reviewText);
		obj.put("rating", this.rating);
		obj.put("summary", this.summary);
		obj.put("review_date", this.reviewDate);
		return obj.toJSONString();
	}

}
