package com.ibm.watson.core;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.ibm.watson.database.DB2Conn;
import com.ibm.watson.database.StoreKeeper;
import com.ibm.watson.database.PostgressConn;
import com.ibm.watson.objects.AmazonReview;

public class WorkFlow {

	// Output formats
	private static final String HTMLFORMAT = "html";
	private static final String PLAINTEXT = "txt";
	private static final String XMLFORMAT = "xml";
	private static final String JSONFORMAT = "json";
	private static final String DB2JDBCFORMAT = "jdbc_db2";
	
	// Amazon Review features
	private static final String PRODUCTID = "asin";
	private static final String REVIEWTEXT = "reviewText";
	private static final String RATING = "overall";
	private static final String UNIXREVIEWTIME = "unixReviewTime";
	private static final String REVIEWERID = "reviewerID";
	private static final String HELPFUL = "helpful";
	private static final String SUMMARY = "summary";
	
	private static final String SEPARATOR = "/";
	
	private static final int batchSize = 1000;
	
	// Database class
	private StoreKeeper keeper = null;

	// JDBC Parameters
	private static String host = null;
	private static String port = null;
	private static String name = null;
	private static String user = null;
	private static String password = null;

	public WorkFlow() {
		host = "HOST";
		port = "PORT";
		name = "DBNAME";
		user = "USERNAME";
		password = "PASSWORD";
		
		// Get a database connection
		keeper = new StoreKeeper(PostgressConn.getInstance(host, port, name, user, password).getConnection());
		keeper.setSchema(user);
		
	}
	
	public void processJsonToDataBase(String inputJsonFile) {
		// Parse the Json Object
		JSONParser jParser = new JSONParser(); 

		// Open up the json file
		try {
			FileReader fr = new FileReader(inputJsonFile);
			BufferedReader br = new BufferedReader(fr);

			ArrayList<AmazonReview> reviewBatch = new ArrayList<AmazonReview>(); 
			
			int counter = 0;
			String documentLine;
			while((documentLine = br.readLine()) != null){
				counter++;

				Object obj = jParser.parse(documentLine);
				JSONObject jsonObject = (JSONObject) obj;
				
				AmazonReview ar = new AmazonReview();
				ar.setReviewerId((String)jsonObject.get(REVIEWERID));
				ar.setProductId((String) jsonObject.get(PRODUCTID));
				ar.setReviewText((String) jsonObject.get(REVIEWTEXT));
				ar.setRating((Double) jsonObject.get(RATING));
				ar.setReviewDate((Long) jsonObject.get(UNIXREVIEWTIME));
				ar.setSummary((String)jsonObject.get(SUMMARY));
				JSONArray helpful = (JSONArray)jsonObject.get(HELPFUL);
				ar.setHelpful((Long)helpful.get(0));
				ar.setNotHelpful((Long)helpful.get(1));
				
				reviewBatch.add(ar);
				
				if(counter % 100 == 0) {
					System.out.println("Count: " + counter);
				}

				// When a batch of reviews are ready commit them to the database
				if(counter % batchSize == 0) {
					System.out.println("Counter: " + counter + " - Inserting next batch to the database");
					keeper.insertReviews(reviewBatch);
					// reset the reviewBacth
					reviewBatch = new ArrayList<AmazonReview>();
				}
			}
			// Insert any remaining reviews to the database
			if(reviewBatch.size() > 0) {
				keeper.insertReviews(reviewBatch);
			}
			
			br.close();
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("Error writing to database: " + e.toString());
		}
	}
	
	public void processJsonToFileSystem(String inputJsonFile, String outputDirectory, String outputFormat) {
		String inputShortName = inputJsonFile.substring(inputJsonFile.lastIndexOf(SEPARATOR)+1, inputJsonFile.lastIndexOf("."));
		String baseFileName = outputDirectory + SEPARATOR + inputShortName;
		
		// Parse the Json Object
		JSONParser jParser = new JSONParser(); 

		// Open up the json file
		try {
			FileReader fr = new FileReader(inputJsonFile);
			BufferedReader br = new BufferedReader(fr);
			
			// Parse each entry line by line
			int entryNumber = 0;
			String documentLine;
			while((documentLine = br.readLine()) != null){
				entryNumber++;
				System.out.println("Processing entry number " + entryNumber);

				Object obj = jParser.parse(documentLine);
				JSONObject jsonObject = (JSONObject) obj;
				
				AmazonReview ar = new AmazonReview();
				ar.setReviewerId((String)jsonObject.get(REVIEWERID));
				ar.setProductId((String) jsonObject.get(PRODUCTID));
				ar.setReviewText((String) jsonObject.get(REVIEWTEXT));
				ar.setRating((Double) jsonObject.get(RATING));
				ar.setReviewDate((Long) jsonObject.get(UNIXREVIEWTIME));
				ar.setSummary((String)jsonObject.get(SUMMARY));
				JSONArray helpful = (JSONArray)jsonObject.get(HELPFUL);
				ar.setHelpful((Long)helpful.get(0));
				ar.setNotHelpful((Long)helpful.get(1));

				createOutputFile(ar, baseFileName, entryNumber, outputFormat);
			}
			
			br.close();
		
		}
		catch(Exception e) {
			System.out.println("Error parsing the JSON: " + e.toString());
		}
	}


	
	private void createOutputFile(AmazonReview ar, String baseFilePathAndName, int entryNumber, String outputFormat) {

		// Expand the entryNumber
		String fileNumber = Integer.toString(entryNumber);
		int noOfZeros = 9 - fileNumber.length();
		for(int i = 0; i < noOfZeros; i++) {
			fileNumber = "0" + fileNumber;
		}
		
		String fileName = baseFilePathAndName + "_" + fileNumber + "." + outputFormat;

		File file = new File(fileName);
		try {
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);

			if(outputFormat.equals(PLAINTEXT)) {
				bw.write(ar.constructPlainText());
			}
			else if(outputFormat.equals(HTMLFORMAT)) {
				bw.write(ar.constructHTML());
			}
			else if(outputFormat.equals(XMLFORMAT)) {
				bw.write(ar.constructXML());
			}
			else if(outputFormat.equals(JSONFORMAT)) {
				bw.write(ar.constructJson());
			}
				
			bw.close();
				
		}
		catch (IOException e) {
			System.out.println("Error - createDocument - " + e.toString());
		}
		
	}
	
}
