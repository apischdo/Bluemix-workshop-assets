DROP TABLE reviews;

CREATE TABLE reviews(
	uuid SERIAL,
	reviewer_id varchar(20),
	product_id varchar(20),
	helpful int,
	not_helpful int,
	review_text text,
	rating real,
	summary varchar(150),
	product_name varchar(250),
	review_date date,
	time_inserted date,
	PRIMARY KEY (uuid)
 );
