# Amazon Title Crawler

## System

Looks up names of products on Amazon.com given their Amazon store id number (asin) retrieved from database, and populates database with corresponding names.

## Classes


## To Run

1. Fill in database credentials in Main
2. `mvn clean install`
3. Run Main
