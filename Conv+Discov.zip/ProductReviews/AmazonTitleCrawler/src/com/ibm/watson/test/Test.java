package com.ibm.watson.test;

import com.ibm.watson.web.WebParser;

public class Test {

	public static void main(String[] args) {
		WebParser wp = new WebParser("http://amazon.com/dp/0912696591");
		System.out.println(wp.getProductTitle());

	}

}
