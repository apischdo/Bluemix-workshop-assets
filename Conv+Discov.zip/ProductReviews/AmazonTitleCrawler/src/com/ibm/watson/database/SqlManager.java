package com.ibm.watson.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SqlManager {
	public static final String copyrightStatement =
	        "Licensed Materials - Property of IBM\n\n" +
	        "(c) Copyright IBM Corp. 2014 All Rights Reserved\n\n" +
	        "US Government Users Restricted Rights - Use, duplication or\n" +
	        "disclosure restricted by GSA ADP Schedule Contract with\n" +
	        "IBM Corp";
	
	private Connection connection = null;
	
	public SqlManager(Connection connection) {
		super();
		this.connection = connection;
	}
	
	public void close() {		
		try {
			connection.close();
		}
		catch (Exception e) {
			System.out.println("Exception closing SqlManager: " + e.toString());
		}
	}
	
	public ResultSet getUnnamedReviews() {
		try {
			String query = "SELECT product_id, uuid FROM reviews WHERE product_name IS NULL";
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet results = statement.executeQuery();
			statement.closeOnCompletion();
			return results;
		} catch (SQLException e) {
			System.out.println("Exception getting resultset: " + e.toString());
			return null;
		}
	}
	
	public void updateReview(String productName, int uuid) {
		try {
			String query = "UPDATE reviews SET product_name = ? WHERE uuid = ?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, productName);
			statement.setInt(2, uuid);
			statement.executeUpdate();
			statement.close();
		} catch (SQLException e) {
			System.out.println("Exception udpating row with id " + uuid + ": " + e.toString());
		}
	}

}
