package com.ibm.watson.main;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import com.ibm.watson.database.PostgresConn;
import com.ibm.watson.database.SqlManager;
import com.ibm.watson.web.WebParser;

public class Main {
	
	private static final String host = "bluemix-sandbox-dal-9-portal.5.dblayer.com";
	private static final String port = "18975";
	private static final String name = "compose";
	private static final String user = "admin";
	private static final String password = "ASKBZNHEASIRNQFN";
	

	public static void main(String[] args) {
		HashMap<String, String> seen = new HashMap<String, String>();
		HashMap<Integer, String> idToName = new HashMap<Integer, String>();
		
		// Connect to database TODO: error check this
		Connection dbConn = PostgresConn.getInstance(host, port, name, user, password).getConnection();
		SqlManager dbManager = new SqlManager(dbConn);
		ResultSet results = dbManager.getUnnamedReviews();
		
		// Loop through entries in database
		try {
			int count = 0;
			while(results.next()) {
				// Extract product id from entry
				String pid = results.getString(1);
				int uuid = results.getInt(2);
				String productName = seen.get(pid);
				// Check if product id has already been scraped in hashtable
				if(productName == null) {
					String url = "https://www.amazon.com/dp/" + pid;
					WebParser wp = new WebParser(url);
					productName = wp.getProductTitle();
					seen.put(pid, productName);
				}
				if(count % 100 == 0) {
					System.out.println(count + ": " + productName);
				}
				if(productName != null) {
					idToName.put(uuid, productName);
				}
				count++;
			}
			results.close();
		} catch (SQLException e) {
			System.out.println("Exception looping over results: "+ e.toString());
			System.exit(1);
		}
		
		System.out.println(seen.size() + " unique product names!");
		
		// Add productNames to database
		int count2 = 0;
		for(int uuid: idToName.keySet()) {
			if(count2 % 100 == 0) {
				System.out.println(count2 + " product names updated.");
			}
			String productName = idToName.get(uuid);
			dbManager.updateReview(productName, uuid);
			count2++;
		}
		dbManager.close();
		
	}

}
