package com.ibm.watson.web;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class WebParser {
	
	private Connection conn = null;
	
	public WebParser(String url) { 
		super();
		conn = Jsoup.connect(url);
	}
	
	public String getProductTitle() {
		try {
			conn.header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X x.y; rv:45.5.0) Gecko/20100101 Firefox/45.5.0");
			Document doc = conn.get();
			Element el = doc.getElementById("productTitle");
			if(el == null) {
				return null;
			}
			String name = el.text();
			if(name.length() > 250) {
				name = name.substring(0, 250);
			}
			return name;
		} catch(Exception e) {
			System.out.println("Exception getting product title: " + e.toString());
			return null;
		}
	}

}
