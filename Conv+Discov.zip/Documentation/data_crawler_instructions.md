# Instructions to set up the WDS Data Crawler

## Important note about operating system support

Data Crawler as recently as v1.3.0 does not actually support macOS or Windows. It happens to work in many circumstances, including with the instructions below. However, the Data Crawler dev team will only support the software on Linux. For more information, see the [internal web site for Data Crawler](https://pages.github.ibm.com/watson-crawler).

## Installation

Environment: Mac or Windows

1.  Download and extract the Data Crawler zip file: <http://ibm.biz/watson-crawler-zip>
2.  Add the Data Crawler bin file to your PATH environment variable

    #### For Mac:
    1.  Open up terminal.
    2.  Run command `sudo nano /etc/paths` to edit your path variable
    3.  At the end of the file add the path to the Data Crawler bin folder
        Example: '/Users/jocelynkong/crawler-1.2.0/bin'
    4.  Close and Re-open terminal.
    5.  Enter command `crawler --version` to test setup.

    #### For Windows:
    1.  From the desktop, right click the **Computer** icon.
    2.  Choose **Properties** from the context menu.
    3.  Click the **Advanced system settings** link.
    4.  Click **Environment Variables**.
    5.  In the section **System Variables**, find the **PATH** environment variable and select it.
    6.  Click **Edit**.
    7.  In the **Edit System Variable**, append on the path to your Data Crawler bin folder. Make sure you separate the paths with a semi-colon
        Example: path\to\bin;C:\crawler-1.2.0\bin
    8.  Click OK. Close all remaining windows by clicking OK.
    9.  Open command line and enter command `crawler --version` to test setup.

## Configuration

1. Copy the 'crawler-x.x.x/share/examples/config' folder into a separate directory and navigate to this copied folder.
2. Open the discovery/discovery_service.conf file. Modify the discovery_service.conf file with your Discovery Service credentials.
3. Open the crawler.conf file. Under the output_adapter section, make sure that class is set to "com.ibm.watson.crawler.discoveryserviceoutputadapter.DiscoveryServiceOutputAdapter" and that config is set to "discovery_service".
4. Follow the instructions below for the type of system you want to crawl to finish configuration.

### Filesystem

Uploads files from local filesystem.

1.  Open seeds/filesystem-seed.conf.
2.  Modify the value attribute directly under the name="url" attribute to the file path that you want to crawl. For example:

    #### Mac:

    Example: value="sdk-fs:///TMP/MY_TEST_DATA/"

    The third slash is needed.

    #### Windows:

    Example: value="sdk-fs://C:/path/to/data"

    The third slash is unneeded.
3. Open crawler.conf and make sure the crawl_config_file is "connectors/filesystem.conf" and the crawl_seed_file is "seeds/filesystem-seed.conf"

### Database

Crawls database and creates JSON document for each row in database where the columns are the fields.

1. Open seeds/database-seed.conf.
2. Modify the value attribute under name="url" to the url of the table in your database you want to crawl. Should be in the form protocol://host:port/dbName/tableName.
  * Example: value="postgresql://bluemix-sandbox.dblayer.com:12345/testdb/testtable"
  * The instructions in the official crawler documentation say you can use a SQL query here. That functionality isn't implemented yet and will give you an error if you try to do it.
3. Now you need to enter your database credentials under the "user-password" field. In order to do this you will have to encrypt your database password.
  * navigate to the top level of your config folder, where id_vcrypt is located
  * run: `vcrypt -e -k id_vcrypt -- “YOUR_PASSWORD_HERE” > encrypted` and copy the entire contents of the generated encrypted file (including the [[vcrypt/3]] text)
  * enter your credentials as data="username:encrypted_password"
4. Under crawl_extender_options, the jdbc-class needs to be the class of the sql driver you want the crawler to use.
  * For postgres, this should be data="org.postgresql.Driver"
  * jtds: "net.sourceforge.jtds.jdbc.Driver"
  * Oracle jdbc: "oracle.jdbc.OracleDriver"
  * mysql: "com.mysql.jdbc.Driver"
  * db2: "com.ibm.db2.jcc.DB2Driver"
5. Also under crawl_extender_options, the connection string needs to be the url to your database prepended with "jdbc:". Example: "jdbc:postgresql://127.0.0.1:5480/databasename"
6. Now open connectors/database.conf. Set the protocol attribute to be the protocol of your database (it should match the protocol you specified in your url in the seed file).
7. Finally, open crawler.conf. Set:
  * crawl_config_file = "connectors/database.conf"
  * crawl_seed_file = "seeds/database-seed.conf"
  * extra_jars_dir = "database" ==> IMPORTANT: This tells the crawler to add the folder crawler-x.x.x/crawler-connector-framework/lib/java/database to the buildpath when it runs. If you are using a protocol that requires a driver not included in this folder (such as mysql or db2), you should add the jar for that driver to this folder and then reference the jdbc driver class from the jar in the database-seed file.
    * mysql: [download jar from here](https://dev.mysql.com/downloads/connector/j/) and add to folder
    * db2: [download license and jdbc jars from here](http://www-01.ibm.com/support/docview.wss?uid=swg21363866) and add both to folder
    * mongodb: various third party jdbc drivers are available, add one to the folder

## To Run

1. Navigate to the top level folder that contains your config folder.
2. Run `crawler testit` to make sure the crawler is crawling the url you expect it to.
3. Run `crawler crawl` to push your files to the Discovery Service.
  * If you get a warning saying `There was an error trying to find path in the config`, you can ignore it. This is given because you specified a config_id instead of a path to a config file in your discovery service configuration.
4. To view the logs of your crawl a logs folder should be automatically generated in the top level folder containing your config folder.

### Tips

* You may need to wait a few minutes for all your documents to be indexed, even after the crawler finishes successfully
* Discovery Service ingestion is rate-limited. If you start receiving errors with a status code of 429, increase the configuration points within the retry section of the output_adapter in crawler.conf
* The code for the crawler is at [this github](https://github.ibm.com/watson-crawler/crawler). If you encounter errors you can search the repository for the error to see what might be causing it.

Please contact Allegra Larche for questions about this guide, or feel free to post an issue in the discovery-prototype repo.

slack: @allegra, #wds-practice

email: Allegra.Larche1@ibm.com
