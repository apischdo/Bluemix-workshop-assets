# Connecting to Bluemix Databases

## PostgreSQL: Compose for Postgres

1. Install postgres for the command line
2. Find credentials for Bluemix instance of compose for postgresql: uri at bottom contains username, password, host, port, and database name
3. From command line, run `psql -h <host> -p <port> -U <username> <databasename>` and then enter your password at the prompt. This should show you a prompt like `dbName=>`
4. [Use this manual](http://www.skrenta.com/rt/man/psql.1.html) as a reference for psql commands

## MySQL: ClearDB

1. Install mysql for the command line
2. Open cleardb database through blue mix and click on the generated database, go to endpoint information tab to get credentials
3. From command line: `mysql -h <host> -u <username> -p <dbname` and enter password at prompt
4. [Use this manual](http://dev.mysql.com/doc/refman/5.7/en/mysql-commands.html) for mysql commands

## DB2
_Coming Soon_
