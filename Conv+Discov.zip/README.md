Title says it all, to gain hands on experience and share the knowledge across our team we are building a WDS prototype.

### Use Case:
Perform financial risk analysis to support investment banking considerations for the Oil & Gas sector. 

### Personas:
We identified an investment banking analyst whose main task is to compile pitch books. Pitch books are marketing presentations filled with investment considerations. An investment banking analyst bases their investment considerations on research in financial documents such as SEC 10K reports. The intended audience for SEC-regulated disclosures is the investing public and researchers from practically every industry are able to discover significant information from the filings. However, the dense and long nature of these documents makes reading and annotating them time consuming and a frustration for investment banking analysts. Furthermore, these documents are generated at a faster pace than one analyst can review them. Investment banking analysts want to identify all risks to a particular company they are analyzing as well as correlations and trends in these risks. This information will fill pitch books with relevant information for investment.


### User Scenario:
Investment banking analyst is interested in identifying risk correlation and trends for a particular company they are analyzing within the Oil & Gas sector.

### What data did we use?
The implemenation intern team crawled SEC 10-K reports from the SEC website, www.sec.gov.  As of 2005, the SEC mandated that companies include a risk factor section in their annual 10-K report. They identified each company of interest via their unique CIK key and, based on the CIK key, they constructed an URL to hit the SEC domain and list the documents submitted by that company. 
https://www.sec.gov/cgibin/browseedgar?action=getcompany&CIK="+CIK+"&type=10K&dateb=&owner=include&count=40/

They implemented a Java program to hit the the SEC website and get the html content of the web page as well as parse it to identify whether there are any 10-K reports filed by that company. Each document was associated with a document id and a section id which was extracted and used to build another URL for navigation to the document web page. We took the list of energy sector companies (as identified by their ticker symbol) from NASDAQ and downloaded their 10-K reports for the past twenty years. 

They were only concerned with the risk factor section of these 10-K documents, labeled Item 1A. The placement of this section is constant throughout all the documents. Hence, they extracted text enclosed between Item 1A and Item 1B. A few small companies had not submitted any concrete information in this section since they were new to the industry or they were too small to be considered by risk analysts. Such reports were filtered out based on the length of the risk factor section. Some companies only started including the risk factor section very recently, so to maintain a strong data set we selected only companies with submissions for five years or more. In our final data set, we had reports from 216 oil and gas companies and crawled around 3300 documents.
