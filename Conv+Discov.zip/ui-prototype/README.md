# Simple Discovery Service Visualization

## **IMPORTANT NOTES:**
1. This sample application works best on Chrome.

## Prerequisites

1.  Discovery service ingested with .json, .pdf, .html, or .doc files
    * For this demo, we have ingested 1000 Amazon reviews related to Home and Kitchen. You can find the reviews [here](https://github.ibm.com/Watson-Implementations-Practice/discovery-prototype/blob/master/ProductReviews/1000.json)
    * If you are using your own custom JSON files to ingest into the service, changes will need to be made in the components to match the custom structure
    
## Run the app locally

1.  Set up environment
    * [Install Node.js 6.x]: https://nodejs.org/en/download/
    * Navigate to the folder holding the `package.json` file
    * run `npm install`

2.  Create/modify the `.env.js` script under the top level directory (same level as `package.json`)

    Sample `.env.js` file
    ``` javascript
    module.exports = {
      VCAP_SERVICES: JSON.stringify({
        "discovery": [
          {
            "credentials": {
              "url": "https://gateway.watsonplatform.net/discovery-experimental/api",
              "password": "password",
              "username": "username"
            }
          }
        ]
      }),
      "version_date": "version date in yyyy-mm-dd format",
      "environment_id": "id",
      "collection_id": "id"
    };
    ```

4.  Replace the password, username, version_date, environment_id, and collection_id in the `.env.js` with your credentials from your Watson Discovery Service.

5.  If you are using your own collection, the structure of your data will be different than what is expected in the application. Please make those structural changes before you start the application. If you would like to use our collection, please reach out to gsolian@us.ibm.com.

6.  run `npm start`

## Deploying it on Bluemix##

1.  Run `npm run build`

2.  In the Bluemix console, create a new Node.js application

3.  Add a Conversation service instance to your new Node.js application through the Bluemix console by clicking on **ADD A SERVICE OR API**. Create and import a new workspace through the Conversation Service.

4.  If you have an already created Conversation service instance, you can bind that service through the Bluemix console by clicking on **BIND A Service OR API**

5.  Set user-defined environment variables on Bluemix console:

    * discovery_username
    * discovery_password
    * discovery_version - Your version date is the last modified date of your environment
    * environment_id
    * collection_id

6.  Ensure in your .cfignore you list the following:
    * node_modules
    * .env.js
    * .tmp
    * *.logs

7.  On the command line, login to Bluemix

    ```
    $ bluemix api https://api.ng.bluemix.net
    $ bluemix login –u <username> -p <password>
    ```

8.  Modify the manifest.yml file. Please make sure that the app name and the host name is correct.

9.  Deploy it on the bluemix
    ```
    $ cf push <app-name>
    ```
    
10.  You could access your app via: `https://<app-name>.mybluemix.net`
