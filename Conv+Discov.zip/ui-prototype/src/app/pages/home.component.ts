import {Component} from '@angular/core';
import '../../public/styles/styles.css';

@Component({
    selector: 'home',
    templateUrl: './home.component.html'
})
export class HomeComponent {

}