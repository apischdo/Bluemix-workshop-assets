'use strict';

export var query_url = window.location.href.split('#')[0] + "discovery/query";

export var escape_map = {
    '&': '\\&',
    '<': '\\<',
    '>': '\\>',
    '"': '\\"',
    '?': '\\?',
    '[': '\\[',
    ']':'\\[',
    '^':'\\^',
    '$':'\\$',
    '.':'\\.',
    '|':'\\|',
    '*':'\\*',
    '+':'\\+',
    '{':'\\{',
    '}':'\\}',
    '(':'\\(',
    ')':'\\)',
    '~':'\\~'
};

export var escape_characters = /[&<>"?\[\]^$.|*+{}~()]/g;

export var queries = {
    "review-timeline": {
        "count": 1000,
        "aggregation": "timeslice(field:metadata.review_date,interval:1year)",
        "return": "aggregations"
    },
    "product-search": {
        "count": 1,
        "query": "metadata.product_name:%s"
    },
    "bubble-chart": {
        "count": 1000,
        "aggregation": "nested(metadata.review_text_enriched.keywords)" +
        ".term(metadata.review_text_enriched.keywords.text.raw,count:50)" +
        ".average(metadata.review_text_enriched.keywords.sentiment.score)",
        "return": "aggregations"
    },
    "product-review-counts": {
        "count": 1000,
        "aggregation": "term(metadata.product_name.raw,count:50)",
        "return": "aggregations"
    },
    "pie-chart-positive": {
        "count": 1000,
        "aggregation": "filter(metadata.review_text_enriched.docSentiment.type:positive)" +
        ".term(metadata.review_text_enriched.keywords.text.raw,count:15)",
        "return": "aggregations"
        //".average(metadata.review_text_enriched.keywords.sentiment.score)"
    },
    "pie-chart-negative":{
        "count": 1000,
        "aggregation": "filter(metadata.review_text_enriched.docSentiment.type:negative)" +
        ".term(metadata.review_text_enriched.keywords.text.raw,count:15)",
        "return": "aggregations"
        //".average(metadata.review_text_enriched.keywords.sentiment.score)"
    },
    "pie-chart-neutral": {
        "count": 1000,
        "aggregation": "filter(metadata.review_text_enriched.docSentiment.type:neutral)" +
        ".term(metadata.review_text_enriched.keywords.text.raw,count:15)",
        "return": "aggregations"
        //".average(metadata.review_text_enriched.keywords.sentiment.score)"
    },
    "sentiment-by-keywords": {
        "count": 1000,
        "aggregation": "filter(metadata.product_name:%s)" +
        ".nested(metadata.review_text_enriched.keywords)" +
        ".[filter(metadata.review_text_enriched.keywords.sentiment.type:positive).term(metadata.review_text_enriched.keywords.text.raw)" +
        ",filter(metadata.review_text_enriched.keywords.sentiment.type:negative).term(metadata.review_text_enriched.keywords.text.raw)" +
        ",filter(metadata.review_text_enriched.keywords.sentiment.type:neutral).term(metadata.review_text_enriched.keywords.text.raw)]",
        "return": "aggregations"
    },
    "product-sentiment": {
        "count": 1000,
        "aggregation": "filter(metadata.product_name:%s)" +
        ".[filter(metadata.review_text_enriched.docSentiment.type:positive)" +
        ",filter(metadata.review_text_enriched.docSentiment.type:negative)" +
        ",filter(metadata.review_text_enriched.docSentiment.type:neutral)]",
        "return": "aggregations"
    },
    "average-product-sentiment": {
        "count": 1000,
        "aggregation": "filter(metadata.product_name:%s).average(metadata.review_text_enriched.docSentiment.score)",
        "return": "aggregations"
    },
    "product-sentiment-timeline": {
        "count": 1000,
        "aggregation": "filter(metadata.product_name:%s).timeslice(field:metadata.review_date,interval:1year).average(metadata.review_text_enriched.docSentiment.score)",
        "return": "aggregations"
    }
};
