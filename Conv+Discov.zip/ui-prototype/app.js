/*eslint-env node*/

//------------------------------------------------------------------------------
// node.js starter application for Bluemix
//------------------------------------------------------------------------------

// This application uses express as its web server
// for more info, see: http://expressjs.com
var express = require('express'),
  //create a new express server
  app = express(),
  extend = require('util')._extend,
  path = require('path');
  pkg = require('./package.json'),
  fs = require('fs'),
  webpack = require('webpack'),
  webpackMiddleware = require('webpack-dev-middleware'),
  webpackHotMiddleware = require('webpack-hot-middleware'),
  config = require('./webpack.config.js'),
  watson = require('watson-developer-cloud')

// Bootstrap application settings
require('./config/express')(app);

// cfenv provides access to your Cloud Foundry environment
// for more info, see: https://www.npmjs.com/package/cfenv
var cfenv = require('cfenv');

var allowCrossDomain = function (req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
  res.header('Access-Control-Allow-Headers', 'Content-Type');

  next();
};

app.use(allowCrossDomain);


//var directory = '/src';
//app.use(express.static(__dirname + directory));

// get the app environment from Cloud Foundry
var appEnv = cfenv.getAppEnv();

var services = appEnv.getServices();
var serviceCredentials;

//services
var discovery;

if (Object.keys(services).length === 0 && services.constructor === Object) {
// load the environment variables - for local testing
  if (fs.existsSync('./.env.js')) {
    Object.assign(process.env, require('./.env.js'));
  }

  serviceCredentials = JSON.parse(process.env.VCAP_SERVICES);

  discovery = new watson.DiscoveryV1({
    version_date: serviceCredentials.discovery[0].credentials.version || "2016-11-07",
    username: serviceCredentials.discovery[0].credentials.username || '<username>',
    password: serviceCredentials.discovery[0].credentials.password || '<password>'
  });

} else {

  serviceCredentials = null;

  discovery = new watson.DiscoveryV1({
    version_date: process.env.discovery_version,
    username: process.env.discovery_username || '<username>',
    password: process.env.discovery_password || '<password>'
  });


}

/** Discovery Methods
 *
 */

app.get('/discovery/getCollections', (req, res, next) => {
  var version_date = process.env.discovery_version;
  var environment_id = process.env.environment_id;
  discovery.getCollections({
      version_date: version_date,
      environment_id: environment_id
    },
    (err, data) => {
      console.log(err);
      if (err) {
        return res.status(err.code || 500).json(err);
      }

      return res.json(data);
    }
  )
  ;
});

app.get('/discovery/query', (req, res, next) => {
  var version_date = process.env.discovery_version;
  var environment_id = process.env.environment_id;
  var collection_id = process.env.collection_id;

  discovery.query({
      version_date: version_date,
      environment_id: environment_id,
      collection_id: collection_id,
      query: req.query.query && req.query.query.length > 0 ? req.query.query : null,
      filter: req.query.filter? req.query.filter : null,
      aggregation: req.query.aggregation? req.query.aggregation : null,
      count: req.query.count && req.query.count > 0 ? req.query.count : null,
      offset: req.query.offset? req.query.offset : null,
      return: req.query.return? req.query.return : null

    },
    (err, data) => {
      if (err) {
        console.log("Error: ");
        console.log(err);
        return res.status(err.code || 500).json(err);
      }

      return res.json(data);
    }
  );
});

// Setting up webpack server
var isDeveloping = process.env.NODE_ENV !== 'production';
var port = isDeveloping ? 3000 : appEnv.port;

if (isDeveloping) {
  const compiler = webpack(config);
  const middleware = webpackMiddleware(compiler, {
    publicPath: config.output.publicPath,
    contentBase: 'src',
    stats: {
      colors: true,
      hash: false,
      timings: true,
      chunks: false,
      chunkModules: false,
      modules: false
    }
  });

  app.use(middleware);
  app.use(webpackHotMiddleware(compiler));
  app.get('*', function response(req, res) {
    //res.write(middleware.fileSystem.readFileSync(path.join(__dirname, 'dist/index.html')));
    res.end();
  });
} else {
  app.use(express.static(__dirname + '/dist'));
  app.get('*', function response(req, res) {
    res.sendFile(path.join(__dirname, 'dist/index.html'));
  });
}



// start server on the specified port and binding host
app.listen(port, '0.0.0.0', function () {
  // print a message when the server starts listening
  console.log('==> 🌎 Listening on port %s. Open up http://0.0.0.0:%s/ in your browser.', port, port);
  //console.log("server starting on " + appEnv.url);
});
