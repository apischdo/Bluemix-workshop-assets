var qa_endpoint = {
    url : 'https://watson-wdc01.ihost.com/instance/nnn/deepqa/v1/question', // Watson QA endpoint
    username : 'your_userid',
	password : 'your_pswd'
};

// Obtain QA credentials from Bluemix Service
function getQAcredentials() {
  var qa_url = "";
  var qa_username = "";
  var qa_password = "";
  var qa_creds = "";
  var services = "";
  
  var vcapservices = parseVcapServices();
  
  if (vcapservices) {
	  services = JSON.parse(process.env.VCAP_SERVICES);
  } else {
	  services = testEnvironment;
  }
  console.log("services: " + JSON.stringify(services));
  qa_creds = services["question_and_answer"][0].credentials;  
  qa_endpoint.url = qa_creds.url;
  qa_endpoint.username = qa_creds.username;
  qa_endpoint.password = qa_creds.password;
  
  return qa_creds;
}

function parseVcapServices() {
    return process && process.env &&
        process.env.VCAP_SERVICES &&
        JSON.parse(process.env.VCAP_SERVICES);
}

// When testing locally, VCAP_SERVICES won't be defined, so use the following
// credentials which are hardcoded based on a QA service binded in bluemix
var testEnvironment = {
  "question_and_answer": [
    {
      "name": "Question and Answer-9j",
      "label": "question_and_answer",
      "plan": "question_and_answer_free_plan",
	  "credentials": {
        "url": "https://gateway.watsonplatform.net/question-and-answer-beta/api",
        "username": "insert userid here from Bluemix service credentials",
        "password": "insert password here from Bluemix service credentials"
      }
    }
  ]
};

exports.ask = function(req, res) {
	//getQAcredentials();
	qin = (req.body).question;	
    qText = qin.replace(/[^\x00-\x7F]|"|\n|\r|\n\r/g, "").trim();
	/*
	console.log('content for analysis: ' + qText);	
	console.log("qa endpoint: " + qa_endpoint.url + '/v1/question/healthcare');
	console.log("qa username: " + qa_endpoint.username);
	console.log("qa pass: " + qa_endpoint.password);
	*/
	
	var question = "{\"question\" : { \"questionText\" : \"" + qText + "\"}}";
	
	require("request")({
		uri : qa_endpoint.url,
		method : "POST",
		headers : {
			'Content-Type' : 'application/json; charset=utf-8',
			'Accept' : 'application/json',
			'X-SyncTimeout' : '30'
		},
		auth : {
			user : qa_endpoint.username,
			pass : qa_endpoint.password
		},
		rejectUnauthorized: false,
		requestCert: true,
		agent: false,
		body: question
	}, function(error, response, body) {
		res(body);
	});
};